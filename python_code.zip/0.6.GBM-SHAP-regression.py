# -*- coding: utf-8 -*-
"""
Created on Thu Jan 16 19:40:56 2025

@author: dell
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import shap
from sklearn.ensemble import GradientBoostingRegressor
import matplotlib.pyplot as plt

# 文件路径
file_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\数据集11.13-分类好.csv'

# 读取CSV文件，指定第一行为列名
df = pd.read_csv(file_path, header=0)

# 提取第1到第16列作为特征变量 X
X = df.iloc[:, 1:18]

# 提取第22列作为类别特征，并将其转换为数字编码
category_feature = df.iloc[:, 21]  # 第22列（索引21）是类别特征
category_feature_encoded = category_feature.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 对类别特征进行归一化
scaler_cat = MinMaxScaler()
category_feature_encoded_normalized = scaler_cat.fit_transform(category_feature_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X = pd.concat([X, pd.DataFrame(category_feature_encoded_normalized, columns=['Category'])], axis=1)

# 提取第17列作为输出变量 y
y = df.iloc[:, 18].values.reshape(-1, 1)

# 对目标变量y进行对数变换并归一化处理
scaler = MinMaxScaler()  # 初始化MinMaxScaler
y = scaler.fit_transform(y)  # 对目标变量进行归一化
y_log_transformed = np.log1p(y)

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=21)

# 对特征变量进行标准化
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# 在每个交叉验证折上进行训练和评估
for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    # 创建并训练GBM回归器
    gbm_regressor_cv = GradientBoostingRegressor(
        max_depth=6,
        learning_rate=0.2,
        n_estimators=431,
        min_samples_split=9,
        random_state=21
    )
    gbm_regressor_cv.fit(X_train_cv, y_train_cv)

    # 在验证集上进行预测
    y_pred_cv = gbm_regressor_cv.predict(X_val)

    # 计算均方误差（MSE）
    mse_cv = mean_squared_error(y_val, y_pred_cv)

    # 将MSE存储到列表中
    cv_scores.append(mse_cv)

# 计算交叉验证的均值和标准差
mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型（使用全部训练数据）
gbm_regressor = GradientBoostingRegressor(
    max_depth=14,
    learning_rate=0.1523,
    n_estimators=903,
    min_samples_split=18,
    min_samples_leaf=9,
    random_state=21
)

# 使用训练集训练最终模型
gbm_regressor.fit(X_train_scaled, y_train.ravel())

# 预测训练集
y_pred_train = gbm_regressor.predict(X_train_scaled)

# 预测测试集
y_pred_test = gbm_regressor.predict(X_test_scaled)

# 逆向变换并确保长度一致
y_actual_train = np.expm1(scaler.inverse_transform(y_train))[:len(y_pred_train)]
y_actual_test = np.expm1(scaler.inverse_transform(y_test))[:len(y_pred_test)]
y_pred_train_actual = np.expm1(scaler.inverse_transform(y_pred_train.reshape(-1, 1)))
y_pred_test_actual = np.expm1(scaler.inverse_transform(y_pred_test.reshape(-1, 1)))

# 创建训练集预测结果的 DataFrame
train_results_df = pd.DataFrame({
    'y_actual_train': y_actual_train.flatten(),
    'y_pred_train': y_pred_train_actual.flatten()
})
train_output_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\regression数据文件\0.6GBMtrain_prediction_results.csv'
train_results_df.to_csv(train_output_path, index=False)

# 创建测试集预测结果的 DataFrame
test_results_df = pd.DataFrame({
    'y_actual_test': y_actual_test.flatten(),
    'y_pred_test': y_pred_test_actual.flatten()
})
test_output_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\regression数据文件\0.6GBMtest_prediction_results.csv'
test_results_df.to_csv(test_output_path, index=False)

# 合并结果
combined_df = pd.concat([train_results_df, test_results_df], axis=1)
combined_output_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\regression数据文件\0.6GBMcombined_prediction_results.csv'
combined_df.to_csv(combined_output_path, index=False)

print(f"合并后的文件已保存到: {combined_output_path}")

# 计算和打印性能指标
mse_train = mean_squared_error(y_actual_train, y_pred_train_actual)
mse_test = mean_squared_error(y_actual_test, y_pred_test_actual)
rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
r2_train = r2_score(y_actual_train, y_pred_train_actual)
r2_test = r2_score(y_actual_test, y_pred_test_actual)

print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
print(f"训练集R平方（R2）: {r2_train:.4f}")
print(f"测试集R平方（R2）: {r2_test:.4f}")

