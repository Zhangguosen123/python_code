# -*- coding: utf-8 -*-
"""
Created on Fri Jan 17 16:41:02 2025

@author: dell
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import shap
import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.inspection import partial_dependence
from scipy.interpolate import splrep, splev
import seaborn as sns

# 文件路径
file_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\数据集11.13-分类好.csv'

# 读取CSV文件，指定第一行为列名
df = pd.read_csv(file_path, header=0)

# 提取第1到第16列作为特征变量 X
X = df.iloc[:, 1:18]

# 提取第22列作为类别特征，并将其转换为数字编码
category_feature = df.iloc[:, 21]  # 第22列（索引21）是类别特征
category_feature_encoded = category_feature.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 对类别特征进行归一化
scaler_cat = MinMaxScaler()
category_feature_encoded_normalized = scaler_cat.fit_transform(category_feature_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X = pd.concat([X, pd.DataFrame(category_feature_encoded_normalized, columns=['Oxidizer Category'])], axis=1)

# 提取第17列作为输出变量 y
y = df.iloc[:, 18].values.reshape(-1, 1)
# 计算最大值和最小值
y_max = np.max(y)
y_min = np.min(y)

print(y_max, y_min)

# 对目标变量y进行对数变换并归一化处理
scaler = MinMaxScaler()  # 初始化MinMaxScaler
y = scaler.fit_transform(y)  # 对目标变量进行归一化
y_log_transformed = np.log1p(y)

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=21)

# 对特征变量进行标准化
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []
train_rmse_list = []  # 用于存储每次交叉验证的训练集RMSE
valid_rmse_list = []  # 用于存储每次交叉验证的验证集RMSE

# 在每个交叉验证折上进行训练和评估
for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    # 创建并训练XGBoost回归器
    xgb_regressor_cv = xgb.XGBRegressor(
        max_depth=6,
        learning_rate=0.2,
        n_estimators=431,
        min_child_weight=9,
        gamma=0,
        random_state=21
    )
    xgb_regressor_cv.fit(X_train_cv, y_train_cv)

    # 在训练集和验证集上进行预测
    y_pred_train_cv = xgb_regressor_cv.predict(X_train_cv)
    y_pred_val_cv = xgb_regressor_cv.predict(X_val)

    # 计算训练集和验证集的MSE
    mse_train_cv = mean_squared_error(y_train_cv, y_pred_train_cv)
    mse_val_cv = mean_squared_error(y_val, y_pred_val_cv)

    # 计算训练集和验证集的RMSE并存储
    rmse_train_cv = np.sqrt(mse_train_cv)
    rmse_val_cv = np.sqrt(mse_val_cv)
    train_rmse_list.append(rmse_train_cv)
    valid_rmse_list.append(rmse_val_cv)

    # 计算当前折的MSE并存储到列表中
    mse_cv = mean_squared_error(y_val, y_pred_val_cv)
    cv_scores.append(mse_cv)

# 计算交叉验证的均值和标准差
mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型（使用全部训练数据）
xg_regressor = xgb.XGBRegressor(
    max_depth=6,
    learning_rate=0.2,
    n_estimators=431,
    min_child_weight=9,
    gamma=0,
    random_state=21,
    eval_metric="rmse"  # 将 eval_metric 移到模型初始化时
)

# 监控训练过程中的损失
eval_set = [(X_train_scaled, y_train.ravel()), (X_test_scaled, y_test.ravel())]
xg_regressor.fit(X_train_scaled, y_train.ravel(), eval_set=eval_set, verbose=False)

# 获取训练过程中的评估结果
results = xg_regressor.evals_result()
epochs = len(results['validation_0']['rmse'])
x_axis = range(0, epochs)

# 绘制过拟合控制图
plt.figure(figsize=(10, 6))
plt.plot(x_axis, results['validation_0']['rmse'], label='Train')
plt.plot(x_axis, results['validation_1']['rmse'], label='Test')
plt.xlabel('Number of Estimators')
plt.ylabel('RMSE')
plt.title('Overfitting Control Plot')
plt.legend()
plt.grid(True)
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'
plt.savefig(f'{save_path}\\overfitting_control_plot.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 使用训练集训练最终模型
xg_regressor.fit(X_train_scaled, y_train.ravel())

# 预测训练集
y_pred_train = xg_regressor.predict(X_train_scaled)

# 预测测试集
y_pred_test = xg_regressor.predict(X_test_scaled)

# 逆向变换并确保长度一致
y_actual_train = np.expm1(scaler.inverse_transform(y_train))[:len(y_pred_train)]
y_actual_test = np.expm1(scaler.inverse_transform(y_test))[:len(y_pred_test)]
y_pred_train_actual = np.expm1(scaler.inverse_transform(y_pred_train.reshape(-1, 1)))
y_pred_test_actual = np.expm1(scaler.inverse_transform(y_pred_test.reshape(-1, 1)))

# 计算性能指标
mse_train = mean_squared_error(y_actual_train, y_pred_train_actual)
mse_test = mean_squared_error(y_actual_test, y_pred_test_actual)
rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
r2_train = r2_score(y_actual_train, y_pred_train_actual)
r2_test = r2_score(y_actual_test, y_pred_test_actual)

# 绘制欠拟合-过拟合散点图
plt.figure(figsize=(8, 6))
plt.scatter(train_rmse_list, valid_rmse_list)  # 绘制多个点
plt.axvline(x=0.02, color='r', linestyle='--')  # 这里的0.2是假设的分界线，可根据实际调整
plt.annotate('underfitting', xy=(0.22, np.max(valid_rmse_list) + 0.02), xytext=(0.22, np.max(valid_rmse_list) + 0.02), 
             ha='left', va='center', arrowprops=dict(arrowstyle='<-'))
plt.annotate('overfitting', xy=(0.22, np.min(valid_rmse_list) - 0.02), xytext=(0.22, np.min(valid_rmse_list) - 0.02), 
             ha='left', va='center', arrowprops=dict(arrowstyle='->'))
plt.xlabel('RMSE (train)')
plt.ylabel('RMSE (valid)')
plt.title('Underfitting vs Overfitting')
plt.grid(True)
plt.savefig(f'{save_path}\\under_over_fitting_plot.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
print(f"训练集R平方（R2）: {r2_train:.4f}")
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(xg_regressor, X_train_scaled)

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 绘制特征重要性图（柱状图）
shap.summary_plot(shap_values.values, X_train_scaled, plot_type="bar", feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 绘制 SHAP 值的密度图（每个特征对预测值的影响）
shap.summary_plot(shap_values.values, X_train_scaled, feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 显示特定样本的 SHAP 解释图（可选）
shap.force_plot(explainer.expected_value, shap_values.values[0, :], X_train_scaled[0, :], feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# --------------- 新增部分：绘制特征相关性矩阵 ---------------
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap
import matplotlib as mpl
# 创建相关性矩阵
correlation_matrix = X.corr()

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'

# 设置matplotlib输出的PDF为Illustrator可编辑的字体
mpl.rcParams['pdf.fonttype'] = 42

# 创建图形
plt.figure(figsize=(10, 8))

# 创建mask，用于显示对角线左侧的区域
mask_left = np.tril(np.ones_like(correlation_matrix, dtype=bool))  # 左下三角区域为True
mask_right = np.triu(np.ones_like(correlation_matrix, dtype=bool))  # 右上三角区域为True

# 创建一个自定义的深红-蓝色颜色映射（更深的颜色）
cmap = LinearSegmentedColormap.from_list("dark_red_blue", ["#8B0000", "white", "#00008B"])  # 深红和深蓝

# 使用新的颜色映射绘制整个热图
sns.heatmap(correlation_matrix, annot=True, cmap=cmap, center=0, linewidths=0.5, fmt=".2f", 
            cbar_kws={'shrink': 0.8}, square=True)

# 设置图框为黑色
for _, spine in plt.gca().spines.items():
    spine.set_edgecolor('black')
    spine.set_linewidth(2)

# 保存图像为PDF格式
plt.savefig(f'{save_path}\\1.0-XGB-correlation_matrix_features.pdf', format='pdf', dpi=300, bbox_inches='tight')

# 显示图形
plt.show()

# --------------- 新增部分：保存mean shap值 ---------------

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(xg_regressor, X_train_scaled)

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 计算每个特征的 mean(|SHAP value|)
mean_shap_values = np.abs(shap_values.values).mean(axis=0)

# 获取特征名称
feature_names = df.columns[1:18].tolist() + ['Oxidizer Category']

# 将 mean(|SHAP value|) 和特征名称合并为一个 DataFrame
shap_values_df = pd.DataFrame({
    'Feature': feature_names,
    'Mean(|SHAP Value|)': mean_shap_values
})

# 按照 'Mean(|SHAP Value|)' 从大到小进行排序
shap_values_df = shap_values_df.sort_values(by='Mean(|SHAP Value|)', ascending=False)

# 保存为 CSV 文件
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\python文件\1.0-XGB-mean_shap_values_sorted.csv'
shap_values_df.to_csv(save_path, index=False)

# 打印输出结果
print("每个特征的 mean(|SHAP value|) 已保存到：", save_path)
print(shap_values_df)

# 完整修复版：适用于旧版本sklearn，不使用grid_values参数

# --------------- 新增部分：绘制PDP和ICE图 ---------------
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.interpolate import splrep, splev
from sklearn.preprocessing import StandardScaler
from sklearn.inspection import partial_dependence

# 配色方案
pdp_color = "#0000FF"  
ice_color = "#696969"  
ci_color = "#D3D3D3"   

# 标准化特征数据
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 前十个特征名称（排除Oxidizer Category）
top_10_features = shap_values_df['Feature'].head(10).tolist()
top_features_filtered = [f for f in top_10_features if f != 'Oxidizer Category']

for feature_name in top_features_filtered:
    print(f"正在绘制特征: {feature_name} 的 PDP和ICE图...")

    feature_idx = df.columns[1:18].tolist().index(feature_name)

    # 计算partial_dependence
    pdp_result = partial_dependence(
        xg_regressor, 
        X=X_test, 
        features=[feature_idx], 
        kind="both", 
        grid_resolution=100
    )

    # 提取PDP数据
    plot_x = pd.Series(pdp_result.grid_values[0], name='x')  
    plot_y = pd.Series(pdp_result.average[0], name='y')  
    plot_i = pdp_result.individual  

    # 获取特征原始数据范围
    min_val = X_test[feature_name].min()
    max_val = X_test[feature_name].max()

    # 截取实际范围内的数据
    valid_idx = (plot_x >= min_val) & (plot_x <= max_val)
    plot_x = plot_x[valid_idx]
    plot_y = plot_y[valid_idx]
    plot_i = plot_i[0][:, valid_idx]

    # 平滑PDP曲线
    tck = splrep(plot_x, plot_y, s=100)
    xnew = np.linspace(plot_x.min(), plot_x.max(), 300)
    ynew = splev(xnew, tck, der=0)

    # ICE数据处理
    plot_df_list = []
    for ice_curve in plot_i:
        df_i = pd.DataFrame({'x': plot_x, 'y': ice_curve})
        plot_df_list.append(df_i)
    plot_df = pd.concat(plot_df_list, ignore_index=True)

    # 绘制图形
    plt.figure(figsize=(10, 6))

    # 绘制ICE背景
    sns.lineplot(data=plot_df, x="x", y="y", color=ci_color, linewidth=0.5, alpha=0.3)

    # 绘制ICE曲线
    sns.lineplot(data=plot_df, x="x", y="y", color=ice_color, linewidth=1.5, linestyle='--', alpha=0.6)

    # 绘制平滑PDP曲线
    plt.plot(xnew, ynew, linewidth=2, color=pdp_color, label='Smoothed PDP')

    # 坐标轴与标签设置
    plt.xlabel(feature_name)
    plt.ylabel('Partial Dependence')
    plt.legend()
    plt.tight_layout()

    # 保存图像
    save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'
    plt.savefig(f'{save_path}\\1.0-XGB-{feature_name}_pdp.pdf', format='pdf', dpi=300, bbox_inches='tight')
    plt.show()


 # --------------- 新增部分：绘制华夫图 ---------------
   
import matplotlib.pyplot as plt
import numpy as np

# 定义各个类别的格子数
category_counts = {'A': 22, 'B': 35, 'Experiment': 43}
categories = list(category_counts.keys())
counts = list(category_counts.values())

# 计算总格子数
total_squares = sum(counts)

# 计算每行的格子数，这里假设每行有10个格子，你可以根据需要调整
num_rows = total_squares // 10 + (1 if total_squares % 10 != 0 else 0)
grid = np.zeros((num_rows, 10), dtype=int)

# 填充格子
index = 0
for i in range(num_rows):
    for j in range(10):
        if index < total_squares:
            for k, count in enumerate(counts):
                if count > 0:
                    grid[i][j] = k + 1
                    counts[k] -= 1
                    index += 1
                    break

# 定义颜色映射
cmap = plt.get_cmap('tab10')
colors = [cmap(i) for i in range(len(categories))]

# 绘制华夫图
fig, ax = plt.subplots()
for i in range(num_rows):
    for j in range(10):
        if grid[i][j] > 0:
            ax.add_patch(plt.Rectangle((j, num_rows - i - 1), 1, 1, color=colors[grid[i][j] - 1]))

# 添加图例
handles = [plt.Rectangle((0, 0), 1, 1, color=color) for color in colors]
ax.legend(handles, categories, loc='lower left', bbox_to_anchor=(1, 0))

# 设置图形属性
ax.set_xlim(0, 10)
ax.set_ylim(0, num_rows)
ax.set_title('Waffle Chart')
ax.set_xticks([])
ax.set_yticks([])
plt.show()

 # --------------- 新增部分：绘制t-SNE图 ---------------

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# 获取 SHAP 值排序后的前三个最重要特征
top_3_features = shap_values_df['Feature'].head(3).tolist()

# 提取这些特征的训练数据
X_tsne_data = X_train_scaled[:, [df.columns[1:18].tolist().index(feature) for feature in top_3_features]]

# 使用 PCA 进行降维到 2 维
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_tsne_data)

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'

# 定义红蓝配色方案
cmap = sns.color_palette("coolwarm", as_cmap=True)  # 红蓝渐变色

# 为每个特征的组合绘制 t-SNE 图
for i in range(3):
    for j in range(i + 1, 3):  # This will give combinations like (0, 1), (0, 2), (1, 2)
        # 获取特征对
        feature_pair = [top_3_features[i], top_3_features[j]]

        # 提取相关特征数据
        X_tsne_pair = X_train_scaled[:, [df.columns[1:18].tolist().index(feature) for feature in feature_pair]]

        # 使用 PCA 降维到 2 维
        X_pca_pair = pca.fit_transform(X_tsne_pair)

        # 使用 t-SNE 进一步降维
        tsne = TSNE(n_components=2, random_state=42)
        X_tsne = tsne.fit_transform(X_pca_pair)

        # 计算 SHAP 值的平均绝对值作为颜色依据
        shap_mean_values = np.mean(np.abs(shap_values.values[:, [df.columns[1:18].tolist().index(feature) for feature in feature_pair]]), axis=1)

        # 绘制 t-SNE 图
        plt.figure(figsize=(10, 6))
        scatter = plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=shap_mean_values, cmap=cmap, alpha=0.7, s=50)

        # 添加颜色条
        plt.colorbar(scatter, label='Mean |SHAP Value|')

        # 设置标签
        plt.xlabel(f't-SNE Component 1 ({feature_pair[0]})')
        plt.ylabel(f't-SNE Component 2 ({feature_pair[1]})')
        # plt.title(f't-SNE Analysis of {feature_pair[0]} vs {feature_pair[1]}')

        # 保存为 PDF
        plt.savefig(f'{save_path}\\1.0-XGB-tsne_{feature_pair[0]}_{feature_pair[1]}_SHAP_interaction.pdf', format='pdf', dpi=300, bbox_inches='tight')

        # 显示图形
        plt.show()


# --------------- 新增部分：适用域（AD）分析 ---------------

from sklearn.metrics import mean_squared_error
import numpy as np

# 计算Tanimoto相似度
def tanimoto_similarity(A, B):
    """计算两个化合物之间的Tanimoto相似度"""
    return np.sum(np.logical_and(A, B)) / float(np.sum(np.logical_or(A, B)))

# 假设我们有一个函数来计算每个化合物的分子指纹（MF），这个函数返回一个二进制向量。
def calculate_molecular_fingerprints(X):
    """
    模拟计算分子指纹的过程
    X: 输入的特征矩阵，每个特征代表一个化学分子。
    返回：每个化学分子的分子指纹（用二进制向量表示）
    """
    # 这里只是一个示例，实际情况中你可以使用库如RDKit来计算分子指纹
    return np.random.randint(2, size=(X.shape[0], 1024))  # 模拟返回1024维的二进制指纹

# 计算训练集和测试集的分子指纹
train_fingerprints = calculate_molecular_fingerprints(X_train)
test_fingerprints = calculate_molecular_fingerprints(X_test)

# 计算Tanimoto相似度
similarity_matrix = np.zeros((len(X_test), len(X_train)))
for i in range(len(X_test)):
    for j in range(len(X_train)):
        similarity_matrix[i, j] = tanimoto_similarity(test_fingerprints[i], train_fingerprints[j])

# 计算最大和平均相似度
max_similarities = np.max(similarity_matrix, axis=1)
mean_similarities = np.mean(similarity_matrix, axis=1)

# 输出平均相似度的阈值
mean_similarity_threshold = np.mean(mean_similarities)  # 选择均值作为阈值
print(f"平均相似度阈值 (均值): {mean_similarity_threshold:.4f}")

# 设定Tanimoto相似度的阈值，这里使用0.3615作为示例阈值
threshold = 0.2546

# 根据相似度阈值判断测试集中的化合物是否在适用域内
in_ad_mask = max_similarities >= threshold

# 适用域内的化合物
X_test_in_ad = X_test[in_ad_mask]
y_test_in_ad = y_test[in_ad_mask]

# 适用域外的化合物
X_test_out_ad = X_test[~in_ad_mask]
y_test_out_ad = y_test[~in_ad_mask]

# 打印适用域内外化合物的数量
print(f"适用域内的化合物数量: {np.sum(in_ad_mask)}")
print(f"适用域外的化合物数量: {np.sum(~in_ad_mask)}")

# 适用域内外的RMSE计算
y_pred_in_ad = xg_regressor.predict(X_test_in_ad)
if len(y_test_in_ad) > 0 and len(y_pred_in_ad) > 0:
    rmse_in_ad = np.sqrt(mean_squared_error(np.expm1(scaler.inverse_transform(y_test_in_ad)), np.expm1(scaler.inverse_transform(y_pred_in_ad.reshape(-1, 1)))))
    print(f"适用域内的RMSE: {rmse_in_ad:.4f}")
else:
    print("适用域内没有化合物，无法计算RMSE")

# 适用域外的RMSE计算
if len(y_test_out_ad) > 0:
    y_pred_out_ad = xg_regressor.predict(X_test_out_ad)
    rmse_out_ad = np.sqrt(mean_squared_error(np.expm1(scaler.inverse_transform(y_test_out_ad)), np.expm1(scaler.inverse_transform(y_pred_out_ad.reshape(-1, 1)))))
    print(f"适用域外的RMSE: {rmse_out_ad:.4f}")
else:
    print("适用域外没有化合物，无法计算RMSE")

# 计算适用域外化合物的比例
out_ad_percentage = 100 * len(X_test_out_ad) / len(X_test)

# 打印适用域外化合物的比例
print(f"适用域外化合物所占比例: {out_ad_percentage:.2f}%")

# 重新计算适用域内的RMSE
if len(y_test_in_ad) > 0:
    rmse_ad = np.sqrt(mean_squared_error(np.expm1(scaler.inverse_transform(y_test_in_ad)), np.expm1(scaler.inverse_transform(y_pred_in_ad.reshape(-1, 1)))))
    print(f"重新计算的适用域内RMSE: {rmse_ad:.4f}")
else:
    print("适用域内没有化合物，无法重新计算RMSE")
