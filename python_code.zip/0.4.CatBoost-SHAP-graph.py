# -*- coding: utf-8 -*-
"""
Created on Sat Jan  4 19:42:50 2025

@author: dell
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import shap
import catboost as cb  # 替换为 CatBoost
import matplotlib.pyplot as plt

# 文件路径
file_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\数据集11.13-分类好.csv'

# 读取CSV文件，指定第一行为列名
df = pd.read_csv(file_path, header=0)

# 提取第1到第16列作为特征变量 X
X = df.iloc[:, 1:18]

# 提取第22列作为类别特征，并将其转换为数字编码
category_feature = df.iloc[:, 21]  # 第22列（索引21）是类别特征
category_feature_encoded = category_feature.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 对类别特征进行归一化
scaler_cat = MinMaxScaler()
category_feature_encoded_normalized = scaler_cat.fit_transform(category_feature_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X = pd.concat([X, pd.DataFrame(category_feature_encoded_normalized, columns=['Oxidizer Category'])], axis=1)

# 提取第17列作为输出变量 y
y = df.iloc[:, 18].values.reshape(-1, 1)
# 计算最大值和最小值
y_max = np.max(y)
y_min = np.min(y)

print(y_max, y_min)

# 对目标变量y进行对数变换并归一化处理
scaler = MinMaxScaler()  # 初始化MinMaxScaler
y = scaler.fit_transform(y)  # 对目标变量进行归一化
y_log_transformed = np.log1p(y)

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=21)

# 对特征变量进行标准化
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []
mse_cv_scores = []  # 用于保存每折的MSE值

# 在每个交叉验证折上进行训练和评估
for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    # 创建并训练CatBoost回归器（替换XGBoost为CatBoost）
    catboost_regressor_cv = cb.CatBoostRegressor(
        iterations=1000,
        depth=6,
        learning_rate=0.2,
        l2_leaf_reg=9,
        random_state=21,
        verbose=0  # 禁用日志输出
    )
    catboost_regressor_cv.fit(X_train_cv, y_train_cv)

    # 在验证集上进行预测
    y_val_pred = catboost_regressor_cv.predict(X_val)

    # 计算均方误差 (MSE) 和 R^2 得分
    mse = mean_squared_error(y_val, y_val_pred)
    r2 = r2_score(y_val, y_val_pred)
    cv_scores.append(r2)  # 记录R^2得分
    mse_cv_scores.append(mse)  # 记录MSE得分

# 计算交叉验证的平均R^2得分和MSE的均值及标准差
mean_cv_r2 = np.mean(cv_scores)
mean_mse_cv = np.mean(mse_cv_scores)
std_mse_cv = np.std(mse_cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 在整个训练集上训练CatBoost模型
catboost_regressor = cb.CatBoostRegressor(
    iterations=1000,
    depth=6,
    learning_rate=0.2,
    l2_leaf_reg=9,
    random_state=21,
    verbose=0  # 禁用日志输出
)
catboost_regressor.fit(X_train_scaled, y_train)

# 在训练集和测试集上进行预测
y_train_pred = catboost_regressor.predict(X_train_scaled)
y_test_pred = catboost_regressor.predict(X_test_scaled)

# 计算训练集和测试集的均方误差 (MSE)、均方根误差 (RMSE) 和 R^2 得分
mse_train = mean_squared_error(y_train, y_train_pred)
rmse_train = np.sqrt(mse_train)
mse_test = mean_squared_error(y_test, y_test_pred)
rmse_test = np.sqrt(mse_test)
r2_train = r2_score(y_train, y_train_pred)
r2_test = r2_score(y_test, y_test_pred)

print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
print(f"训练集R平方（R2）: {r2_train:.4f}")
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(catboost_regressor, X_train_scaled)

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 绘制特征重要性图（柱状图）
shap.summary_plot(shap_values.values, X_train_scaled, plot_type="bar", feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 绘制 SHAP 值的密度图（每个特征对预测值的影响）
shap.summary_plot(shap_values.values, X_train_scaled, feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 显示特定样本的 SHAP 解释图（可选）
shap.force_plot(explainer.expected_value, shap_values.values[0, :], X_train_scaled[0, :], feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# --------------- 新增部分：绘制特征相关性矩阵 ---------------
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap

# 创建相关性矩阵
correlation_matrix = X.corr()

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'

import matplotlib as mpl
# 设置matplotlib输出的PDF为Illustrator可编辑的字体
mpl.rcParams['pdf.fonttype'] = 42

# 创建图形
plt.figure(figsize=(10, 8))

# 创建mask，用于显示对角线左侧的区域
mask_left = np.tril(np.ones_like(correlation_matrix, dtype=bool))  # 左下三角区域为True
mask_right = np.triu(np.ones_like(correlation_matrix, dtype=bool))  # 右上三角区域为True

# 创建一个自定义的深红-蓝色颜色映射（更深的颜色）
cmap = LinearSegmentedColormap.from_list("dark_red_blue", ["#8B0000", "white", "#00008B"])  # 深红和深蓝

# 使用新的颜色映射绘制整个热图
sns.heatmap(correlation_matrix, annot=True, cmap=cmap, center=0, linewidths=0.5, fmt=".2f", 
            cbar_kws={'shrink': 0.8}, square=True)

# 设置图框为黑色
for _, spine in plt.gca().spines.items():
    spine.set_edgecolor('black')
    spine.set_linewidth(2)

# 保存图像为PDF格式
plt.savefig(f'{save_path}\\4.0-CatBoost-correlation_matrix_features.pdf', format='pdf', dpi=300, bbox_inches='tight')

# 显示图形
plt.show()

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(catboost_regressor, X_train_scaled)  # 注意此处使用 catboost_regressor

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 绘制特征重要性图（柱状图）
shap.summary_plot(shap_values.values, X_train_scaled, plot_type="bar", feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 绘制 SHAP 值的密度图（每个特征对预测值的影响）
shap.summary_plot(shap_values.values, X_train_scaled, feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 显示特定样本的 SHAP 解释图（可选）
shap.force_plot(explainer.expected_value, shap_values.values[0, :], X_train_scaled[0, :], feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(catboost_regressor, X_train_scaled)  # 注意此处使用 catboost_regressor

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 计算每个特征的 mean(|SHAP value|)
mean_shap_values = np.abs(shap_values.values).mean(axis=0)

# 获取特征名称
feature_names = df.columns[1:18].tolist() + ['Oxidizer Category']

# 将 mean(|SHAP value|) 和特征名称合并为一个 DataFrame
shap_values_df = pd.DataFrame({
    'Feature': feature_names,
    'Mean(|SHAP Value|)': mean_shap_values
})

# 按照 'Mean(|SHAP Value|)' 从大到小进行排序
shap_values_df = shap_values_df.sort_values(by='Mean(|SHAP Value|)', ascending=False)

# 保存为 CSV 文件
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\python文件\4.0-CatBoost-mean_shap_values_sorted.csv'
shap_values_df.to_csv(save_path, index=False)

# 打印输出结果
print("每个特征的 mean(|SHAP value|) 已保存到：", save_path)
print(shap_values_df)
