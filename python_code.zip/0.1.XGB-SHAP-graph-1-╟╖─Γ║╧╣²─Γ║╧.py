# -*- coding: utf-8 -*-
"""
Created on Fri Jan 17 16:41:02 2025

@author: dell
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import shap
import xgboost as xgb
import matplotlib.pyplot as plt
from sklearn.inspection import partial_dependence
from scipy.interpolate import splrep, splev
import seaborn as sns

# 文件路径
file_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\数据集11.13-分类好.csv'

# 读取CSV文件，指定第一行为列名
df = pd.read_csv(file_path, header=0)

# 提取第1到第16列作为特征变量 X
X = df.iloc[:, 1:18]

# 提取第22列作为类别特征，并将其转换为数字编码
category_feature = df.iloc[:, 21]  # 第22列（索引21）是类别特征
category_feature_encoded = category_feature.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 对类别特征进行归一化
scaler_cat = MinMaxScaler()
category_feature_encoded_normalized = scaler_cat.fit_transform(category_feature_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X = pd.concat([X, pd.DataFrame(category_feature_encoded_normalized, columns=['Oxidizer Category'])], axis=1)

# 提取第17列作为输出变量 y
y = df.iloc[:, 18].values.reshape(-1, 1)
# 计算最大值和最小值
y_max = np.max(y)
y_min = np.min(y)

print(y_max, y_min)

# 对目标变量y进行对数变换并归一化处理
scaler = MinMaxScaler()  # 初始化MinMaxScaler
y = scaler.fit_transform(y)  # 对目标变量进行归一化
y_log_transformed = np.log1p(y)

train_rmse_list = []  # 用于存储训练集RMSE
valid_rmse_list = []  # 用于存储验证集RMSE

# 进行多次随机划分训练集和测试集
num_iterations = 50  # 划分次数，可按需调整
for _ in range(num_iterations):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=np.random.randint(0, 1000))

    # 对特征变量进行标准化
    scaler_X = StandardScaler()
    X_train_scaled = scaler_X.fit_transform(X_train)
    X_test_scaled = scaler_X.transform(X_test)

    # 训练最终模型（使用全部训练数据）
    xg_regressor = xgb.XGBRegressor(
        max_depth=6,
        learning_rate=0.2,
        n_estimators=431,
        min_child_weight=9,
        gamma=0,
        random_state=21
    )

    xg_regressor.fit(X_train_scaled, y_train.ravel())

    # 预测训练集和验证集
    y_pred_train = xg_regressor.predict(X_train_scaled)
    y_pred_test = xg_regressor.predict(X_test_scaled)

    # 计算训练集和验证集的MSE
    mse_train = mean_squared_error(y_train, y_pred_train)
    mse_test = mean_squared_error(y_test, y_pred_test)

    # 计算训练集和验证集的RMSE
    rmse_train = np.sqrt(mse_train)
    rmse_test = np.sqrt(mse_test)

    # 计算训练集和测试集的R2
    r2_train = r2_score(y_train, y_pred_train)
    r2_test = r2_score(y_test, y_pred_test)

    # 打印训练集和测试集的指标
    print(f"训练集均方误差（MSE）: {mse_train:.4f}")
    print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
    print(f"测试集均方误差（MSE）: {mse_test:.4f}")
    print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
    print(f"训练集R平方（R2）: {r2_train:.4f}")
    print(f"测试集R平方（R2）: {r2_test:.4f}")

    train_rmse_list.append(rmse_train)
    valid_rmse_list.append(rmse_test)

# 绘制欠拟合-过拟合散点图
plt.figure(figsize=(8, 6))
plt.scatter(train_rmse_list, valid_rmse_list)  # 绘制多个点
plt.axvline(x=0.016, color='r', linestyle='--')  # 这里的0.2是假设的分界线，可根据实际调整
plt.annotate('underfitting', xy=(0.22, np.max(valid_rmse_list) + 0.02), xytext=(0.22, np.max(valid_rmse_list) + 0.02), 
             ha='left', va='center', arrowprops=dict(arrowstyle='<-'))
plt.annotate('overfitting', xy=(0.22, np.min(valid_rmse_list) - 0.02), xytext=(0.22, np.min(valid_rmse_list) - 0.02), 
             ha='left', va='center', arrowprops=dict(arrowstyle='->'))
plt.xlabel('RMSE (train)')
plt.ylabel('RMSE (valid)')
plt.title('Underfitting vs Overfitting')
plt.grid(True)
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'
plt.savefig(f'{save_path}\\under_over_fitting_plot.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.show()

# 后续代码保持不变，省略部分重复代码...

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(xg_regressor, X_train_scaled)

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 绘制特征重要性图（柱状图）
shap.summary_plot(shap_values.values, X_train_scaled, plot_type="bar", feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 绘制 SHAP 值的密度图（每个特征对预测值的影响）
shap.summary_plot(shap_values.values, X_train_scaled, feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 显示特定样本的 SHAP 解释图（可选）
shap.force_plot(explainer.expected_value, shap_values.values[0, :], X_train_scaled[0, :], feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# # --------------- 新增部分：绘制特征相关性矩阵 ---------------
# import matplotlib.pyplot as plt
# import seaborn as sns
# from matplotlib.colors import LinearSegmentedColormap
# import matplotlib as mpl
# # 创建相关性矩阵
# correlation_matrix = X.corr()

# # 设置保存路径
# save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'

# # 设置matplotlib输出的PDF为Illustrator可编辑的字体
# mpl.rcParams['pdf.fonttype'] = 42

# # 创建图形
# plt.figure(figsize=(10, 8))

# # 创建mask，用于显示对角线左侧的区域
# mask_left = np.tril(np.ones_like(correlation_matrix, dtype=bool))  # 左下三角区域为True
# mask_right = np.triu(np.ones_like(correlation_matrix, dtype=bool))  # 右上三角区域为True

# # 创建一个自定义的深红-蓝色颜色映射（更深的颜色）
# cmap = LinearSegmentedColormap.from_list("dark_red_blue", ["#8B0000", "white", "#00008B"])  # 深红和深蓝

# # 使用新的颜色映射绘制整个热图
# sns.heatmap(correlation_matrix, annot=True, cmap=cmap, center=0, linewidths=0.5, fmt=".2f", 
#             cbar_kws={'shrink': 0.8}, square=True)

# # 设置图框为黑色
# for _, spine in plt.gca().spines.items():
#     spine.set_edgecolor('black')
#     spine.set_linewidth(2)

# # 保存图像为PDF格式
# plt.savefig(f'{save_path}\\1.0-XGB-correlation_matrix_features.pdf', format='pdf', dpi=300, bbox_inches='tight')

# # 显示图形
# plt.show()

# # --------------- 新增部分：保存mean shap值 ---------------

# # 创建 SHAP Explainer 对象
# explainer = shap.Explainer(xg_regressor, X_train_scaled)

# # 计算 SHAP 值，并禁用加性检查
# shap_values = explainer(X_train_scaled, check_additivity=False)

# # 计算每个特征的 mean(|SHAP value|)
# mean_shap_values = np.abs(shap_values.values).mean(axis=0)

# # 获取特征名称
# feature_names = df.columns[1:18].tolist() + ['Oxidizer Category']

# # 将 mean(|SHAP value|) 和特征名称合并为一个 DataFrame
# shap_values_df = pd.DataFrame({
#     'Feature': feature_names,
#     'Mean(|SHAP Value|)': mean_shap_values
# })

# # 按照 'Mean(|SHAP Value|)' 从大到小进行排序
# shap_values_df = shap_values_df.sort_values(by='Mean(|SHAP Value|)', ascending=False)

# # 保存为 CSV 文件
# save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\python文件\1.0-XGB-mean_shap_values_sorted.csv'
# shap_values_df.to_csv(save_path, index=False)

# # 打印输出结果
# print("每个特征的 mean(|SHAP value|) 已保存到：", save_path)
# print(shap_values_df)

# # --------------- 新增部分：绘制PDP和ICE图 ---------------

# # 获取根据SHAP值排序后前三个最重要特征的名称，存储在列表中
# top_3_features = shap_values_df['Feature'].head(3).tolist()

# # 遍历前三个特征的名称，对每个特征进行PDP图的绘制
# for feature_name in top_3_features:
#     # 打印正在绘制的特征名称，用于提示当前的绘制进度
#     print(f"正在绘制 {feature_name} 的 PDP 图...")

#     # 获取当前特征在原始数据特征列中的索引位置
#     feature_idx = df.columns[1:18].tolist().index(feature_name)

#     # 提取偏依赖数据
#     # 使用sklearn的partial_dependence函数计算指定模型在测试集上关于当前特征的偏依赖数据
#     # kind="both"表示同时计算平均偏依赖和个体偏依赖
#     # grid_resolution=50指定了计算偏依赖时特征值的网格分辨率
#     pdp_result = partial_dependence(xg_regressor, X_test_scaled, [feature_idx], kind="both", grid_resolution=50)
#     # 从偏依赖结果中提取特征值，将其转换为pandas的Series对象，并命名为'x'
#     plot_x = pd.Series(pdp_result.grid_values[0]).rename('x')  
#     # 从偏依赖结果中提取平均偏依赖数据，将其转换为pandas的Series对象，并命名为'y'
#     plot_y = pd.Series(pdp_result.average[0]).rename('y')      
#     # 从偏依赖结果中提取个体偏依赖曲线数据
#     plot_i = pdp_result.individual                            

#     # 平滑曲线
#     # 使用scipy的splrep函数对特征值和平均偏依赖数据进行样条插值，s=30是平滑参数
#     tck = splrep(plot_x, plot_y, s=30)
#     # 在特征值的最小值和最大值之间均匀生成300个新的特征值点
#     xnew = np.linspace(plot_x.min(), plot_x.max(), 300)
#     # 使用splev函数根据样条插值结果，计算新特征值点对应的平滑后的平均偏依赖值
#     ynew = splev(xnew, tck, der=0)

#     # 准备个体数据
#     # 用于存储每个样本的个体偏依赖数据的DataFrame列表
#     plot_df_list = []
#     # 如果存在个体偏依赖数据
#     if plot_i is not None:  
#         # 遍历每个样本的个体偏依赖数据
#         for a in plot_i[0]:
#             # 将个体偏依赖数据转换为pandas的Series对象
#             a2 = pd.Series(a)
#             # 将特征值和个体偏依赖数据合并为一个DataFrame
#             df_i = pd.concat([plot_x, a2.rename('y')], axis=1)
#             # 将合并后的DataFrame添加到列表中
#             plot_df_list.append(df_i)
#         # 将列表中的所有DataFrame合并为一个大的DataFrame，忽略原来的索引
#         plot_df = pd.concat(plot_df_list, ignore_index=True)
#     else:
#         # 如果不存在个体偏依赖数据，创建一个空的DataFrame
#         plot_df = pd.DataFrame(columns=['x', 'y'])

#     # 绘制图形
#     # 创建一个新的图形窗口，设置图形的大小为宽10英寸，高6英寸
#     plt.figure(figsize=(10, 6))
#     # 绘制个体条件期望（ICE）图和置信区间
#     # 使用seaborn的lineplot函数，根据个体偏依赖数据绘制线图
#     # color='k'指定线条颜色为黑色，linewidth=1.5指定线条宽度为1.5，linestyle='--'指定线条样式为虚线，alpha=0.6指定线条透明度为0.6
#     sns.lineplot(data=plot_df, x="x", y="y", color='k', linewidth=1.5, linestyle='--', alpha=0.6)
#     # 绘制平滑后的平均偏依赖曲线
#     # 使用matplotlib的plot函数，根据新生成的特征值和平滑后的平均偏依赖值绘制曲线
#     # linewidth=2指定线条宽度为2，color='r'指定线条颜色为红色，label='Smoothed PDP'为曲线添加标签
#     plt.plot(xnew, ynew, linewidth=2, color='r', label='Smoothed PDP')

#     # 设置图形的标题，显示当前绘制的特征名称
#     plt.title(f'Partial Dependence Plot for {feature_name}')
#     # 设置图形的x轴标签为当前特征的名称
#     plt.xlabel(feature_name)
#     # 设置图形的y轴标签为偏依赖值
#     plt.ylabel('Partial Dependence')
#     # 显示图形的图例，用于标识不同曲线的含义
#     plt.legend()
#     # 自动调整图形的布局，确保所有元素都能完整显示
#     plt.tight_layout()
#     # 设置保存路径
#     save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'
#     # 将绘制好的图形保存为PDF文件，文件名包含特征名称
#     # save_path是之前定义的保存路径，format='pdf'指定保存格式为PDF，dpi=300指定图片分辨率为300，bbox_inches='tight'确保图形周围没有多余的空白
#     plt.savefig(f'{save_path}\\{feature_name}_pdp.pdf', format='pdf', dpi=300, bbox_inches='tight')
#     # 显示绘制好的图形
#     plt.show()