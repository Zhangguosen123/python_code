# -*- coding: utf-8 -*-
"""
Created on Thu Jan 16 16:57:50 2025

@author: dell
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, KFold
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import shap
from sklearn.ensemble import GradientBoostingRegressor
import matplotlib.pyplot as plt

# 文件路径
file_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\数据集11.13-分类好.csv'

# 读取CSV文件，指定第一行为列名
df = pd.read_csv(file_path, header=0)

# 提取第1到第16列作为特征变量 X
X = df.iloc[:, 1:18]

# 提取第22列作为类别特征，并将其转换为数字编码
category_feature = df.iloc[:, 21]  # 第22列（索引21）是类别特征
category_feature_encoded = category_feature.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 对类别特征进行归一化
scaler_cat = MinMaxScaler()
category_feature_encoded_normalized = scaler_cat.fit_transform(category_feature_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X = pd.concat([X, pd.DataFrame(category_feature_encoded_normalized, columns=['Oxidizer Category'])], axis=1)

# 提取第17列作为输出变量 y
y = df.iloc[:, 18].values.reshape(-1, 1)
# 计算最大值和最小值
y_max = np.max(y)
y_min = np.min(y)

print(y_max, y_min)

# 对目标变量y进行对数变换并归一化处理
scaler = MinMaxScaler()  # 初始化MinMaxScaler
y = scaler.fit_transform(y)  # 对目标变量进行归一化
y_log_transformed = np.log1p(y)

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=21)

# 对特征变量进行标准化
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 使用K折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# 在每个交叉验证折上进行训练和评估
for train_index, val_index in kf.split(X_train_scaled):
    X_train_cv, X_val = X_train_scaled[train_index], X_train_scaled[val_index]
    y_train_cv, y_val = y_train[train_index], y_train[val_index]

    # 创建并训练GBM回归器
    gbm_regressor_cv = GradientBoostingRegressor(
        max_depth=6,
        learning_rate=0.2,
        n_estimators=431,
        min_samples_split=9,
        random_state=21
    )
    gbm_regressor_cv.fit(X_train_cv, y_train_cv)

    # 在验证集上进行预测
    y_pred_cv = gbm_regressor_cv.predict(X_val)

    # 计算均方误差（MSE）
    mse_cv = mean_squared_error(y_val, y_pred_cv)

    # 将MSE存储到列表中
    cv_scores.append(mse_cv)

# 计算交叉验证的均值和标准差
mean_mse_cv = np.mean(cv_scores)
std_mse_cv = np.std(cv_scores)

print(f"交叉验证均方误差（MSE）的均值: {mean_mse_cv:.4f}")
print(f"交叉验证均方误差（MSE）的标准差: {std_mse_cv:.4f}")

# 训练最终模型（使用全部训练数据）
gbm_regressor = GradientBoostingRegressor(
    max_depth=14,
    learning_rate=0.1523,
    n_estimators=903,
    min_samples_split=18,
    min_samples_leaf=10,
    random_state=21
)

# 使用训练集训练最终模型
gbm_regressor.fit(X_train_scaled, y_train.ravel())

# 预测训练集
y_pred_train = gbm_regressor.predict(X_train_scaled)

# 预测测试集
y_pred_test = gbm_regressor.predict(X_test_scaled)

# 逆向变换并确保长度一致
y_actual_train = np.expm1(scaler.inverse_transform(y_train))[:len(y_pred_train)]
y_actual_test = np.expm1(scaler.inverse_transform(y_test))[:len(y_pred_test)]
y_pred_train_actual = np.expm1(scaler.inverse_transform(y_pred_train.reshape(-1, 1)))
y_pred_test_actual = np.expm1(scaler.inverse_transform(y_pred_test.reshape(-1, 1)))

# 计算性能指标
mse_train = mean_squared_error(y_actual_train, y_pred_train_actual)
mse_test = mean_squared_error(y_actual_test, y_pred_test_actual)
rmse_train = np.sqrt(mse_train)
rmse_test = np.sqrt(mse_test)
r2_train = r2_score(y_actual_train, y_pred_train_actual)
r2_test = r2_score(y_actual_test, y_pred_test_actual)

print(f"训练集均方误差（MSE）: {mse_train:.4f}")
print(f"训练集均方根误差（RMSE）: {rmse_train:.4f}")
print(f"测试集均方误差（MSE）: {mse_test:.4f}")
print(f"测试集均方根误差（RMSE）: {rmse_test:.4f}")
print(f"训练集R平方（R2）: {r2_train:.4f}")
print(f"测试集R平方（R2）: {r2_test:.4f}")

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(gbm_regressor, X_train_scaled)

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 绘制特征重要性图（柱状图）
shap.summary_plot(shap_values.values, X_train_scaled, plot_type="bar", feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 绘制 SHAP 值的密度图（每个特征对预测值的影响）
shap.summary_plot(shap_values.values, X_train_scaled, feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# 显示特定样本的 SHAP 解释图（可选）
shap.force_plot(explainer.expected_value, shap_values.values[0, :], X_train_scaled[0, :], feature_names=df.columns[1:18].tolist() + ['Oxidizer Category'])

# --------------- 新增部分：绘制前十特征SHAP图 ---------------

import matplotlib
matplotlib.use('Agg')
import shap
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'

# 设置 matplotlib 输出的 PDF 为 Illustrator 可编辑的字体
mpl.rcParams['pdf.fonttype'] = 42

# 创建 SHAP Explainer 对象
explainer = shap.Explainer(gbm_regressor, X_train_scaled)

# 计算 SHAP 值，并禁用加性检查
shap_values = explainer(X_train_scaled, check_additivity=False)

# 计算每个特征的平均 SHAP 值
mean_shap_values = np.abs(shap_values.values).mean(axis=0)

# 获取特征名称
feature_names = df.columns[1:18].tolist() + ['Oxidizer Category']

# 创建一个 DataFrame 来存储特征名称和对应的平均 SHAP 值
feature_importance_df = pd.DataFrame({
    'feature': feature_names,
    'mean_shap': mean_shap_values
})

# 按平均 SHAP 值降序排序
feature_importance_df = feature_importance_df.sort_values(by='mean_shap', ascending=False)

# 选择平均 SHAP 值最高的前十特征
top_10_features = feature_importance_df.head(10)['feature'].tolist()

# 获取前十特征的索引
top_10_indices = [feature_names.index(feature) for feature in top_10_features]

# 提取前十特征的 SHAP 值
top_10_shap_values = shap_values.values[:, top_10_indices]
top_10_X_train_scaled = X_train_scaled[:, top_10_indices]

# 创建独立的图形对象用于绘制特征重要性图（柱状图）
plt.figure()
shap.summary_plot(top_10_shap_values, top_10_X_train_scaled, plot_type="bar", feature_names=top_10_features)
plt.savefig(f'{save_path}\\6.0-GBM-feature_importance_top10.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.close()  # 关闭当前图形窗口

# 创建独立的图形对象用于绘制 SHAP 值的密度图
plt.figure()
shap.summary_plot(top_10_shap_values, top_10_X_train_scaled, feature_names=top_10_features)
plt.savefig(f'{save_path}\\6.0-GBM-shap_density_top10.pdf', format='pdf', dpi=300, bbox_inches='tight')
plt.close()  # 关闭当前图形窗口

# 显示特定样本的 SHAP 解释图（可选）
force_plot = shap.force_plot(explainer.expected_value, top_10_shap_values[0, :], top_10_X_train_scaled[0, :], feature_names=top_10_features)
shap.save_html(f'{save_path}\\6.0-GBM-force_plot_top10_sample1.html', force_plot)

# --------------- 新增部分：绘制特征相关性矩阵 ---------------
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap

# 创建相关性矩阵
correlation_matrix = X.corr()

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'

import matplotlib as mpl
# 设置matplotlib输出的PDF为Illustrator可编辑的字体
mpl.rcParams['pdf.fonttype'] = 42

# 创建图形
plt.figure(figsize=(10, 8))

# 创建mask，用于显示对角线左侧的区域
mask_left = np.tril(np.ones_like(correlation_matrix, dtype=bool))  # 左下三角区域为True
mask_right = np.triu(np.ones_like(correlation_matrix, dtype=bool))  # 右上三角区域为True

# 创建一个自定义的深红-蓝色颜色映射（更深的颜色）
cmap = LinearSegmentedColormap.from_list("dark_red_blue", ["#8B0000", "white", "#00008B"])  # 深红和深蓝

# 使用新的颜色映射绘制整个热图
sns.heatmap(correlation_matrix, annot=True, cmap=cmap, center=0, linewidths=0.5, fmt=".2f", 
            cbar_kws={'shrink': 0.8}, square=True)

# 设置图框为黑色
for _, spine in plt.gca().spines.items():
    spine.set_edgecolor('black')
    spine.set_linewidth(2)

# 保存图像为PDF格式
plt.savefig(f'{save_path}\\6.0-GBM-correlation_matrix_features.pdf', format='pdf', dpi=300, bbox_inches='tight')

# 显示图形
plt.show()

# --------------- 新增部分：计算并保存SHAP值的平均绝对值 ---------------

# 计算每个特征的 mean(|SHAP value|)
mean_shap_values = np.abs(shap_values.values).mean(axis=0)

# 获取特征名称
feature_names = df.columns[1:18].tolist() + ['Oxidizer Category']

# 将 mean(|SHAP value|) 和特征名称合并为一个 DataFrame
shap_values_df = pd.DataFrame({
    'Feature': feature_names,
    'Mean(|SHAP Value|)': mean_shap_values
})

# 按照 'Mean(|SHAP Value|)' 从大到小进行排序
shap_values_df = shap_values_df.sort_values(by='Mean(|SHAP Value|)', ascending=False)

# 保存为 CSV 文件
save_path_shap = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\python文件\6.0-GBM-mean_shap_values_sorted.csv'
shap_values_df.to_csv(save_path_shap, index=False)

# 打印输出结果
print("每个特征的 mean(|SHAP value|) 已保存到：", save_path_shap)
print(shap_values_df)

# --------------- 新增部分：绘制PDP和ICE图 ---------------
from sklearn.inspection import partial_dependence
from scipy.interpolate import splrep, splev
import seaborn as sns

# 跳过Oxidizer Category特征，获取前三个可绘制PDP图的特征名称
feature_names_filtered = [f for f in shap_values_df['Feature'].tolist() if f != 'Oxidizer Category']
top_3_features = feature_names_filtered[:3]

# 定义配色列表，与参考图顺序对应
color_schemes = ["#00008B", "#8A2BE2", "#FFE4B5"]  # 修改为参考图的配色

# 遍历前三个特征的名称，对每个特征进行PDP图的绘制
for idx, feature_name in enumerate(top_3_features):
    # 打印正在绘制的特征名称，用于提示当前的绘制进度
    print(f"正在绘制 {feature_name} 的 PDP 图...")

    # 获取当前特征在原始数据特征列中的索引位置
    feature_idx = df.columns[1:18].tolist().index(feature_name) if feature_name in df.columns[1:18].tolist() else \
        (df.columns.tolist().index(feature_name) if feature_name in df.columns.tolist() else None)

    # 提取偏依赖数据
    # 使用sklearn的partial_dependence函数计算指定模型在测试集上关于当前特征的偏依赖数据
    # kind="both"表示同时计算平均偏依赖和个体偏依赖
    # grid_resolution=50指定了计算偏依赖时特征值的网格分辨率
    pdp_result = partial_dependence(gbm_regressor, X_test_scaled, [feature_idx], kind="both", grid_resolution=50)
    # 从偏依赖结果中提取特征值，将其转换为pandas的Series对象，并命名为'x'
    plot_x = pd.Series(pdp_result.grid_values[0]).rename('x')  
    # 从偏依赖结果中提取平均偏依赖数据，将其转换为pandas的Series对象，并命名为'y'
    plot_y = pd.Series(pdp_result.average[0]).rename('y')      
    # 从偏依赖结果中提取个体偏依赖曲线数据
    plot_i = pdp_result.individual                            

    # 平滑曲线
    # 使用scipy的splrep函数对特征值和平均偏依赖数据进行样条插值，s=30是平滑参数
    tck = splrep(plot_x, plot_y, s=30)
    # 在特征值的最小值和最大值之间均匀生成300个新的特征值点
    xnew = np.linspace(plot_x.min(), plot_x.max(), 300)
    # 使用splev函数根据样条插值结果，计算新特征值点对应的平滑后的平均偏依赖值
    ynew = splev(xnew, tck, der=0)

    # 准备个体数据
    # 用于存储每个样本的个体偏依赖数据的DataFrame列表
    plot_df_list = []
    # 如果存在个体偏依赖数据
    if plot_i is not None:  
        # 遍历每个样本的个体偏依赖数据
        for a in plot_i[0]:
            # 将个体偏依赖数据转换为pandas的Series对象
            a2 = pd.Series(a)
            # 将特征值和个体偏依赖数据合并为一个DataFrame
            df_i = pd.concat([plot_x, a2.rename('y')], axis=1)
            # 将合并后的DataFrame添加到列表中
            plot_df_list.append(df_i)
        # 将列表中的所有DataFrame合并为一个大的DataFrame，忽略原来的索引
        plot_df = pd.concat(plot_df_list, ignore_index=True)
    else:
        # 如果不存在个体偏依赖数据，创建一个空的DataFrame
        plot_df = pd.DataFrame(columns=['x', 'y'])

    # 绘制图形
    # 创建一个新的图形窗口，设置图形的大小为宽10英寸，高6英寸
    plt.figure(figsize=(10, 6))
    # 绘制个体条件期望（ICE）图和置信区间
    # 使用seaborn的lineplot函数，根据个体偏依赖数据绘制线图
    # 使用定义的配色列表中的颜色
    sns.lineplot(data=plot_df, x="x", y="y", color=color_schemes[idx], linewidth=1.5, linestyle='--', alpha=0.6)
    # 绘制平滑后的平均偏依赖曲线
    # 使用定义的配色列表中的颜色
    plt.plot(xnew, ynew, linewidth=2, color=color_schemes[idx], label='Smoothed PDP')

    # 设置图形的标题，显示当前绘制的特征名称
    plt.title(f'Partial Dependence Plot for {feature_name}')
    # 设置图形的x轴标签为当前特征的名称
    plt.xlabel(feature_name)
    # 设置图形的y轴标签为偏依赖值
    plt.ylabel('Partial Dependence')
    # 显示图形的图例，用于标识不同曲线的含义
    plt.legend()
    # 自动调整图形的布局，确保所有元素都能完整显示
    plt.tight_layout()
    # 设置保存路径
    save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'
    # 将绘制好的图形保存为PDF文件，文件名包含特征名称
    # save_path是之前定义的保存路径，format='pdf'指定保存格式为PDF，dpi=300指定图片分辨率为300，bbox_inches='tight'确保图形周围没有多余的空白
    plt.savefig(f'{save_path}\\GBM-{feature_name}_pdp.pdf', format='pdf', dpi=300, bbox_inches='tight')
    # 显示绘制好的图形
    plt.show()
    
# --------------- 新增部分：绘制t-SNE图 ---------------

from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np

# 获取SHAP值排序后的前三个最重要特征，但去掉'Oxidizer Category'
top_3_features = shap_values_df['Feature'].head(4).tolist()  # 获取前四个特征
top_3_features.remove('Oxidizer Category')  # 去掉'Oxidizer Category'
top_3_features = top_3_features[:3]  # 确保只保留前三个特征

# 提取这些特征的训练数据
X_tsne_data = X_train_scaled[:, [df.columns[1:18].tolist().index(feature) for feature in top_3_features]]

# 使用PCA进行降维到2维
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_tsne_data)

# 设置保存路径
save_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\成果图'

# 自定义颜色映射
cmap = plt.get_cmap("viridis")  # 使用简单的 viridis 色彩映射

# 为每个特征的组合绘制 t-SNE 图
for i in range(3):
    for j in range(i + 1, 3):  # This will give combinations like (0, 1), (0, 2), (1, 2)
        # 获取特征对
        feature_pair = [top_3_features[i], top_3_features[j]]

        # 提取相关特征数据
        X_tsne_pair = X_train_scaled[:, [df.columns[1:18].tolist().index(feature) for feature in feature_pair]]

        # 使用 PCA 降维到 2 维
        X_pca_pair = pca.fit_transform(X_tsne_pair)

        # 使用 t-SNE 进一步降维
        tsne = TSNE(n_components=2, random_state=42)
        X_tsne = tsne.fit_transform(X_pca_pair)

        # 绘制 t-SNE 图
        plt.figure(figsize=(10, 6))
        
        # 使用 SHAP 值对点进行配色
        scatter = plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=np.mean(np.abs(shap_values.values[:, [df.columns[1:18].tolist().index(feature) for feature in feature_pair]]), axis=1), cmap=cmap, alpha=0.7, s=50)

        # 添加颜色条
        plt.colorbar(scatter, label='Mean |SHAP Value|')

        # 设置标签
        plt.xlabel(f't-SNE Component 1 ({feature_pair[0]} vs {feature_pair[1]})')
        plt.ylabel(f't-SNE Component 2 ({feature_pair[0]} vs {feature_pair[1]})')
        plt.title(f't-SNE Analysis of {feature_pair[0]} vs {feature_pair[1]}')

        # 保存为PDF
        plt.savefig(f'{save_path}\\6.0-GBM-tsne_{feature_pair[0]}_{feature_pair[1]}_SHAP_interaction.pdf', format='pdf', dpi=300, bbox_inches='tight')

        # 显示图形
        plt.show()

