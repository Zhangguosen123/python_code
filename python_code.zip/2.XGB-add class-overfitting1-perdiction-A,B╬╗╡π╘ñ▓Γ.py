# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 17:49:28 2025

@author: dell
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import xgboost as xgb

# 文件路径
file_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\python文件\数据集11.13-分类好.csv'
new_data_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\python文件\AB位点热图预测数据.csv'
output_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\python文件\AB位点预测结果1.csv'

# 读取原始训练数据
df = pd.read_csv(file_path, header=0)

# 提取第1到第16列作为特征变量 X
X = df.iloc[:, 1:18]

# # 🚀 使用 LabelEncoder 转换第0列为数值
# le = LabelEncoder()
# X.iloc[:, 0] = le.fit_transform(X.iloc[:, 0])  # 转换成整数编码

# # 🚀 检查转换后的第0列
# print("转换后的第0列（数值化）:", X.iloc[:, 0].head())

# 提取第22列作为类别特征，并将其转换为数字编码
category_feature = df.iloc[:, 21]  # 第22列（索引21）是类别特征
category_feature_encoded = category_feature.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 对类别特征进行归一化
scaler_cat = MinMaxScaler()
category_feature_encoded_normalized = scaler_cat.fit_transform(category_feature_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X = pd.concat([X, pd.DataFrame(category_feature_encoded_normalized, columns=['Oxidizer Category'])], axis=1)

# 提取第17列作为输出变量 y
y = df.iloc[:, 18].values.reshape(-1, 1)

# 目标变量归一化
scaler = MinMaxScaler()
y = scaler.fit_transform(y)

# 对目标变量进行对数变换
y_log_transformed = np.log1p(y)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=21)

# 特征标准化
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 训练XGBoost回归器
xg_regressor = xgb.XGBRegressor(
    max_depth=6,
    learning_rate=0.2,
    n_estimators=431,
    min_child_weight=9,
    gamma=0,
    random_state=21,
    objective='reg:squaredlogerror'  # 使用 squared log error 作为目标函数
)

xg_regressor.fit(X_train_scaled, y_train.ravel())

# 打印训练集和测试集分布
print("训练集特征范围：", X_train.min(axis=0), X_train.max(axis=0))
print("测试集特征范围：", X_test.min(axis=0), X_test.max(axis=0))

# ---- 对新数据集进行预测 ----

# 读取新数据集
new_df = pd.read_csv(new_data_path, header=0)

# 删除全为空的行，避免后续处理问题
new_df = new_df.dropna(how='all').reset_index(drop=True)

# 提取第1到第17列作为特征变量 X_new
X_new = new_df.iloc[:, 1:18]

# 提取第22列（索引21）作为类别特征
category_feature_new = new_df.iloc[:, 21]

# 类别特征编码
category_feature_new_encoded = category_feature_new.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 类别特征归一化（使用原有scaler）
category_feature_new_encoded_normalized = scaler_cat.transform(category_feature_new_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X_new = pd.concat([
    X_new.reset_index(drop=True), 
    pd.DataFrame(category_feature_new_encoded_normalized, columns=['Oxidizer Category'])
], axis=1)

# 标准化特征
X_new_scaled = scaler_X.transform(X_new)

# 使用训练好的模型预测
y_new_pred = xg_regressor.predict(X_new_scaled)

# 逆变换预测值，恢复真实值
y_new_pred_actual = np.expm1(scaler.inverse_transform(y_new_pred.reshape(-1, 1)))

# 限制预测值范围
y_new_pred_actual = np.clip(np.abs(y_new_pred_actual), 0.001, 1.329)

# 保存预测结果
new_df['Predicted_K'] = y_new_pred_actual

# 保存到文件
new_df.to_csv(output_path, index=False)

print(f"预测完成，结果已保存到文件: {output_path}")


