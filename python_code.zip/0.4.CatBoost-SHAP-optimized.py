# -*- coding: utf-8 -*-
"""
Created on Thu Jan 16 16:29:58 2025

@author: dell
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score
import catboost as cb
from bayes_opt import BayesianOptimization

# 文件路径
file_path = r'H:\研究生学习（人工智能+环境）\论文学习\成宇杰师兄\数据集\数据集11.13-分类好.csv'

# 读取CSV文件，指定第一行为列名
df = pd.read_csv(file_path, header=0)

# 提取第1到第16列作为特征变量 X
X = df.iloc[:, 1:18]

# 提取第22列作为类别特征，并将其转换为数字编码
category_feature = df.iloc[:, 21]  # 第22列（索引21）是类别特征
category_feature_encoded = category_feature.replace({
    'PAA': 0, 'PMS': 1, 'PS': 2
})

# 对类别特征进行归一化
scaler_cat = MinMaxScaler()
category_feature_encoded_normalized = scaler_cat.fit_transform(category_feature_encoded.values.reshape(-1, 1))

# 将归一化后的类别特征加入到特征变量 X 中
X = pd.concat([X, pd.DataFrame(category_feature_encoded_normalized, columns=['Category'])], axis=1)

# 提取第17列作为输出变量 y
y = df.iloc[:, 18].values.reshape(-1, 1)

# 对目标变量y进行对数变换并归一化处理
scaler = MinMaxScaler()  # 初始化MinMaxScaler
y = scaler.fit_transform(y)  # 对目标变量进行归一化

# 将数据集划分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=21)

# 对特征变量进行标准化
scaler_X = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

# 定义贝叶斯优化目标函数
def catboost_evaluate(iterations, depth, learning_rate, l2_leaf_reg):
    # 使用CatBoost进行训练
    model = cb.CatBoostRegressor(
        iterations=int(iterations),
        depth=int(depth),
        learning_rate=learning_rate,
        l2_leaf_reg=l2_leaf_reg,
        random_state=21,
        verbose=0  # 禁用日志输出
    )
    
    # 训练模型
    model.fit(X_train_scaled, y_train.ravel())
    
    # 预测测试集
    y_pred_test = model.predict(X_test_scaled)
    
    # 计算R2作为性能指标
    r2_test = r2_score(y_test, y_pred_test)
    
    return r2_test  # 返回R2作为目标函数

# 定义超参数搜索空间
param_space = {
    'iterations': (100, 2000),  # 迭代次数
    'depth': (3, 10),  # 树的最大深度
    'learning_rate': (0.01, 0.3),  # 学习率
    'l2_leaf_reg': (1, 10)  # L2正则化系数
}

# 贝叶斯优化器的初始化
opt = BayesianOptimization(
    f=catboost_evaluate,  # 目标函数
    pbounds=param_space,  # 超参数范围
    random_state=42
)

# 进行优化，设置迭代次数
opt.maximize(
    init_points=10,  # 初始点数
    n_iter=50  # 优化迭代次数
)

# 获取最佳参数与最佳分数
params_best = opt.max["params"]
score_best = opt.max["target"]

# 打印最佳参数与最佳分数
print("\n最佳参数: ", params_best)
print("最佳R²得分: ", score_best)
